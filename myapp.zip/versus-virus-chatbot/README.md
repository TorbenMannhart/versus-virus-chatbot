# KURABOT
Chatbot that explains the purpose and conditions of short-time work (Kurzarbeit) in Switzerland

Implemented for the Versus Virus Hackathon 2020

https://www.versusvirus.ch/
